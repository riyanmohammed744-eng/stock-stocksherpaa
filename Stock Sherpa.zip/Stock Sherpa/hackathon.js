'use strict';
const $=s=>document.querySelector(s), K='stocksherpa.v1';
const CATS=['Grains & Staples','Dairy','Snacks','Beverages','Personal Care','Household','Cooking Essentials','Other'];
const UNITS=['packet','piece','kg','g','litre','ml','box','bottle','dozen'];
const PAGES=[['dashboard','Dashboard','layout-dashboard'],['inventory','Inventory','package'],['alerts','Stock Alerts','bell-ring'],['reorder','Reorder Assistant','shopping-cart'],['ledger','Stock Ledger','book-open'],['expiry','Expiry Tracker','calendar-clock'],['settings','Settings','settings']];
const inr=n=>'₹'+Math.round(n).toLocaleString('en-IN');
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const day=d=>{const x=new Date();x.setDate(x.getDate()+d);return x.toISOString().slice(0,10)};
// name|cat idx|unit|cost|sell|qty|min|target|supplier|expiry offset(0 none)
const RAW=`Basmati Rice 5kg|0|packet|520|575|14|8|30|Sharma Traders|0
Aashirvaad Atta 5kg|0|packet|215|235|22|10|40|Sharma Traders|120
Loose Atta|0|kg|40|45|60|30|120|Sharma Traders|90
Toor Dal|0|kg|128|145|18|12|40|Sharma Traders|0
Moong Dal|0|kg|105|118|6|10|30|Sharma Traders|0
Chana Dal|0|kg|82|95|25|10|30|Sharma Traders|0
Sugar|0|kg|41|46|0|20|60|Sharma Traders|0
Iodised Salt 1kg|0|packet|22|26|40|15|50|Sharma Traders|400
Poha|0|kg|48|56|12|8|25|Sharma Traders|150
Sooji|0|kg|42|50|9|8|25|Sharma Traders|100
Besan 500g|0|packet|48|55|15|8|25|Sharma Traders|110
Rajma|0|kg|118|135|7|8|20|Sharma Traders|0
Fortune Sunflower Oil 1L|6|packet|128|142|20|12|40|Gupta Wholesale|180
Mustard Oil 1L|6|bottle|150|168|4|8|24|Gupta Wholesale|200
Ghee 500ml|6|bottle|290|325|10|6|20|Gupta Wholesale|140
Turmeric Powder 200g|6|packet|42|52|16|8|24|Gupta Wholesale|220
Red Chilli Powder 200g|6|packet|56|68|13|8|24|Gupta Wholesale|210
Garam Masala 100g|6|packet|52|64|3|6|18|Gupta Wholesale|190
Jeera 100g|6|packet|38|46|20|6|18|Gupta Wholesale|230
Tomato Ketchup 500g|6|bottle|88|102|11|5|15|Gupta Wholesale|-4
Maggi 70g|2|packet|12|14|90|40|150|Metro Distributors|160
Parle-G|2|packet|4.5|5|120|60|240|Metro Distributors|90
Good Day Cashew|2|packet|9|10|8|30|120|Metro Distributors|70
Lays Classic|2|packet|17|20|35|20|60|Metro Distributors|45
Kurkure Masala|2|packet|17|20|0|20|60|Metro Distributors|40
Bourbon Biscuits|2|packet|8.5|10|44|20|80|Metro Distributors|6
Haldiram Bhujia 200g|2|packet|42|50|18|10|30|Metro Distributors|12
Dairy Milk Silk|2|piece|68|80|14|10|30|Metro Distributors|80
Amul Taza Milk 500ml|1|packet|27|30|24|30|80|Amul Dairy Agency|2
Curd 400g|1|packet|28|32|10|12|30|Amul Dairy Agency|5
Amul Butter 100g|1|packet|55|60|15|10|30|Amul Dairy Agency|25
Paneer 200g|1|packet|72|85|5|8|20|Amul Dairy Agency|9
Cheese Slices|1|packet|118|135|9|6|18|Amul Dairy Agency|50
Buttermilk 200ml|1|packet|9|12|30|20|50|Amul Dairy Agency|3
Eggs Tray|1|dozen|72|84|12|6|24|Amul Dairy Agency|14
Tata Tea Gold 250g|3|packet|118|135|16|8|30|Cool Beverages Co|300
Nescafe Classic 50g|3|packet|152|175|9|5|15|Cool Beverages Co|400
Coca-Cola 750ml|3|bottle|34|40|28|18|60|Cool Beverages Co|120
Thums Up 2L|3|bottle|78|90|0|8|24|Cool Beverages Co|110
Frooti 200ml|3|piece|9|10|40|24|72|Cool Beverages Co|90
Packaged Water 1L|3|bottle|14|20|50|30|100|Cool Beverages Co|300
Red Bull|3|piece|105|125|12|6|24|Cool Beverages Co|200
Real Juice 1L|3|box|88|105|6|6|18|Cool Beverages Co|55
Clinic Plus Shampoo|4|bottle|88|105|14|8|24|HomeCare Agencies|450
Sachet Shampoo|4|piece|1.6|2|150|80|300|HomeCare Agencies|500
Lux Soap|4|piece|31|36|30|20|60|HomeCare Agencies|600
Dettol Soap|4|piece|38|45|22|15|50|HomeCare Agencies|600
Colgate 200g|4|piece|98|112|13|8|24|HomeCare Agencies|520
Sensodyne 70g|4|piece|118|136|4|5|15|HomeCare Agencies|520
Surf Excel 1kg|5|packet|122|140|15|10|30|HomeCare Agencies|700
Vim Liquid 500ml|5|bottle|92|105|11|8|24|HomeCare Agencies|650
Harpic 500ml|5|bottle|88|102|7|6|18|HomeCare Agencies|700
Colin Glass Cleaner|5|bottle|74|88|6|5|15|HomeCare Agencies|700
Garbage Bags|5|packet|55|70|10|6|18|HomeCare Agencies|0
Agarbatti|7|box|18|25|34|15|50|Metro Distributors|0
Matchbox|7|packet|9|10|60|30|100|Metro Distributors|0
Candles|7|packet|22|30|12|8|24|Metro Distributors|0
Batteries AA|7|packet|38|50|2|6|18|Metro Distributors|900`;
let S, charts=[], ui={page:'dashboard',q:'',cat:'',stat:'',sort:'name',lf:'',lt:'',sel:{},qty:{}};
function seed(){const t=Date.now();S={store:'Sharma Kirana Store',products:RAW.split('\n').map((l,i)=>{const f=l.split('|');
 return{id:'P'+(1001+i),name:f[0],sku:'SKU-'+(1001+i),barcode:'890'+String(1000000000+i*7919).slice(0,10),cat:CATS[+f[1]],unit:f[2],cost:+f[3],price:+f[4],qty:+f[5],min:+f[6],target:+f[7],supplier:f[8],phone:'',expiry:+f[9]?day(+f[9]):'',added:day(-30)}}),ledger:[]};save()}
function load(){try{const d=JSON.parse(localStorage.getItem(K));if(d&&d.products)return d}catch(e){}return null}
function save(){try{localStorage.setItem(K,JSON.stringify(S))}catch(e){toast('Storage full or blocked','error')}}
const st=p=>p.qty<=0?'out':p.qty<=p.min?'low':'in';
const badge=p=>({in:'<span class="badge b-in">In stock</span>',low:'<span class="badge b-low">Low stock</span>',out:'<span class="badge b-out">Out of stock</span>'}[st(p)]);
const dleft=p=>p.expiry?Math.round((new Date(p.expiry+'T00:00')-new Date().setHours(0,0,0,0))/864e5):null;
const alerts=()=>S.products.filter(p=>st(p)!=='in');
const need=()=>alerts().filter(p=>p.target>p.qty);
function toast(m,t=''){const e=document.createElement('div');e.className='toast '+t;e.textContent=m;$('#toasts').append(e);setTimeout(()=>e.remove(),3200)}
function icons(){lucide.createIcons()}
// ---------- stock ----------
function adjust(id,delta,reason='Manual Correction',type){const p=S.products.find(x=>x.id===id);if(!p)return;
 const prev=p.qty,n=Math.max(0,prev+delta);if(n===prev)return toast('Stock cannot go below zero','warn');
 p.qty=n;type=type||(reason==='Sale'?'Sale':reason==='Return'?'Return':reason==='Manual Correction'||reason==='Other'?'Correction':delta>0?'Stock In':'Stock Out');
 S.ledger.unshift({id:'T'+String(Date.now()).slice(-8)+Math.floor(Math.random()*9),ts:new Date().toISOString(),pid:p.id,name:p.name,sku:p.sku,type,change:n-prev,prev,now:n,reason});
 save();render();toast('Stock updated successfully.');if(st(p)!=='in'&&prev>p.min||n===0)toast(p.name+' is now below minimum stock.','warn');
 document.querySelectorAll(`[data-q="${id}"]`).forEach(e=>e.classList.add('pop'))}
const stepper=p=>`<span class="stepper">${[-5,-1].map(d=>`<button ${p.qty<=0?'disabled':''} onclick="adjust('${p.id}',${d})" aria-label="${d}">${d}</button>`).join('')}<span class="qty" data-q="${p.id}">${p.qty}</span>${[1,5].map(d=>`<button onclick="adjust('${p.id}',${d})" aria-label="+${d}">+${d}</button>`).join('')}<button onclick="adjModal('${p.id}')" aria-label="Bulk adjust" title="Bulk adjust">±</button></span>`;
// ---------- modal ----------
function modal(h){const m=$('#modal');m.innerHTML=`<div class="sheet" role="dialog" aria-modal="true">${h}</div>`;m.hidden=false;icons();const f=m.querySelector('input,select');f&&f.focus()}
function closeM(){$('#modal').hidden=true;$('#modal').innerHTML=''}
$('#modal').onclick=e=>{if(e.target.id==='modal')closeM()};
document.onkeydown=e=>{if(e.key==='Escape')closeM()};
function confirmM(msg,fn){window._c=fn;modal(`<h2>Are you sure?</h2><p class="mut" style="margin:10px 0 18px">${esc(msg)}</p><div class="acts"><button class="btn" onclick="closeM()">Cancel</button><button class="btn danger" onclick="closeM();_c()">Yes, continue</button></div>`)}
function adjModal(id){const p=S.products.find(x=>x.id===id);
 modal(`<h2>Adjust stock · ${esc(p.name)}</h2><p class="mut">Current: ${p.qty} ${p.unit}</p><div class="form"><label>Change (+ adds, − removes)<input class="in" id="a_d" type="number" value="1"></label><label>Reason<select id="a_r">${['Sale','Supplier Delivery','Manual Correction','Return','Damaged Product','Other'].map(r=>`<option>${r}</option>`).join('')}</select></label></div><div class="acts"><button class="btn" onclick="closeM()">Cancel</button><button class="btn primary" onclick="const d=parseInt($('#a_d').value);if(!d)return toast('Enter a non-zero number','error');adjust('${id}',d,$('#a_r').value);closeM()">Save</button></div>`)}
function prodModal(id){const p=S.products.find(x=>x.id===id)||{name:'',sku:'',barcode:'',cat:CATS[0],unit:'packet',cost:'',price:'',qty:0,min:5,target:20,supplier:'',phone:'',expiry:''};
 const f=(k,l,t='text',req)=>`<label>${l}${req?' <span style="color:var(--red)">*</span>':''}<input class="in" id="f_${k}" type="${t}" value="${esc(p[k])}" ${t==='number'?'min="0" step="any"':''}><span class="err" id="e_${k}"></span></label>`;
 const sel=(k,l,a)=>`<label>${l}<select id="f_${k}">${a.map(o=>`<option ${o===p[k]?'selected':''}>${o}</option>`).join('')}</select></label>`;
 modal(`<h2>${id?'Edit product':'Add product'}</h2><div class="form"><div class="full">${f('name','Product name','text',1)}</div>${f('sku','SKU')}${f('barcode','Barcode')}${sel('cat','Category',CATS)}${sel('unit','Unit',UNITS)}${f('cost','Cost price (₹)','number',1)}${f('price','Selling price (₹)','number',1)}${f('qty','Quantity','number',1)}${f('min','Minimum stock','number',1)}${f('target','Target stock','number',1)}${f('supplier','Supplier')}${f('phone','Supplier phone (optional)','tel')}${f('expiry','Expiry date (optional)','date')}</div><div class="acts">${id?`<button class="btn danger" onclick="delP('${id}')">Delete</button>`:''}<button class="btn" onclick="closeM()">Cancel</button><button class="btn primary" onclick="saveP('${id||''}')">Save product</button></div>`)}
function saveP(id){const v=k=>$('#f_'+k).value.trim(),o={};let ok=true;
 document.querySelectorAll('.err').forEach(e=>e.textContent='');document.querySelectorAll('.in').forEach(e=>e.classList.remove('bad'));
 const bad=(k,m)=>{ok=false;$('#e_'+k).textContent=m;$('#f_'+k).classList.add('bad')};
 ['name','cat','unit','sku','barcode','supplier','phone','expiry'].forEach(k=>o[k]=v(k));
 if(!o.name)bad('name','Enter a product name.');
 ['cost','price','qty','min','target'].forEach(k=>{const n=parseFloat(v(k));if(isNaN(n)||n<0)bad(k,'Enter a number, 0 or more.');o[k]=n});
 if(ok&&o.price<o.cost)toast('Selling price is below cost price.','warn');
 if(!ok)return;
 if(id){const p=S.products.find(x=>x.id===id),prev=p.qty;Object.assign(p,o);if(prev!==o.qty){p.qty=prev;adjust(id,o.qty-prev,'Manual Correction')}}
 else{const n=S.products.reduce((m,p)=>Math.max(m,+p.id.slice(1)),1000)+1;S.products.unshift({...o,id:'P'+n,sku:o.sku||'SKU-'+n,added:day(0)});}
 save();closeM();render();toast(id?'Product updated.':'Product added to inventory.')}
function delP(id){confirmM('This permanently deletes the product. Ledger history stays.',()=>{S.products=S.products.filter(p=>p.id!==id);save();render();toast('Product deleted.')})}
// ---------- pages ----------
const P={};
const kpi=(l,v,s,i,c='')=>`<div class="card kpi ${c}"><div class="l">${l}<i data-lucide="${i}"></i></div><b>${v}</b><small>${s}</small></div>`;
const fin=()=>{let v=0,r=0;S.products.forEach(p=>{v+=p.qty*p.cost;r+=p.qty*p.price});return{v,r,p:r-v,m:r?(r-v)/r*100:0}};
P.dashboard=()=>{const f=fin(),a=alerts(),low=a.filter(p=>st(p)==='low').length,out=a.length-low,ex=S.products.filter(p=>dleft(p)!==null&&dleft(p)<=30).sort((x,y)=>dleft(x)-dleft(y));
 return`<div class="head"><div><h1>Good morning, Store Owner</h1><small>Here's what's happening with your inventory today.</small></div><div class="mut">${new Date().toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long'})}</div></div>
 ${a.length?`<div class="banner"><i data-lucide="alert-triangle"></i><span><b>${a.length} products</b> need attention: ${low} low, ${out} out of stock.</span><a onclick="go('alerts')">View alerts</a></div>`:''}
 <div class="grid kpis">${kpi('Total products',S.products.length,'Unique items in inventory','package')}${kpi('Stock value',inr(f.v),'At cost price','wallet')}${kpi('Low stock',low,'At or below minimum','trending-down',low?'warn':'')}${kpi('Out of stock',out,'Quantity is zero','x-circle',out?'hot':'')}${kpi('Potential revenue',inr(f.r),'If all stock sells at list price (estimate)','indian-rupee')}${kpi('Potential profit',inr(f.p),`${f.m.toFixed(1)}% gross margin · estimate`,'piggy-bank')}</div>
 <div class="grid two"><div class="card"><h2>Inventory analytics</h2><small>Stock value at cost by category</small><div class="chart"><canvas id="c1"></canvas></div></div><div class="card"><h2>Stock health</h2><small>Products by status</small><div class="chart"><canvas id="c2"></canvas></div></div></div>
 <div class="grid three"><div class="card"><h2>Stock alerts</h2>${a.sort((x,y)=>x.qty/x.min-y.qty/y.min).slice(0,5).map(p=>`<div class="row"><span>${esc(p.name)}<br><small>${p.qty}/${p.min} ${p.unit}</small></span>${badge(p)}</div>`).join('')||'<p class="empty">All stocked up.</p>'}</div>
 <div class="card"><h2>Recent activity</h2>${S.ledger.slice(0,5).map(t=>`<div class="row"><span>${esc(t.name)}<br><small>${t.type} · ${t.reason}</small></span><b>${t.change>0?'+':''}${t.change}</b></div>`).join('')||'<p class="empty">No stock changes yet. Use +1 / −1 on any product.</p>'}</div>
 <div class="card"><h2>Expiry watch</h2>${ex.slice(0,5).map(p=>`<div class="row"><span>${esc(p.name)}<br><small>${p.expiry}</small></span>${expBadge(p)}</div>`).join('')||'<p class="empty">Nothing expiring within 30 days.</p>'}</div></div>
 <div class="card" style="margin-top:14px"><h2 style="margin-bottom:10px">Quick actions</h2><div class="tools" style="margin:0"><button class="btn primary" onclick="prodModal()"><i data-lucide="plus"></i>Add product</button><button class="btn" onclick="go('inventory')"><i data-lucide="plus-minus"></i>Record stock</button><button class="btn" onclick="go('reorder')"><i data-lucide="shopping-cart"></i>Generate order</button><button class="btn" onclick="go('alerts')"><i data-lucide="bell"></i>View alerts</button></div></div>`};
P.dashboard.after=()=>{const by={};S.products.forEach(p=>by[p.cat]=(by[p.cat]||0)+p.qty*p.cost);
 const c=(id,cfg)=>charts.push(new Chart($(id),cfg)),o={maintainAspectRatio:false,plugins:{legend:{display:false}}};
 c('#c1',{type:'bar',data:{labels:Object.keys(by),datasets:[{data:Object.values(by).map(Math.round),backgroundColor:'#166534',borderRadius:6}]},options:{...o,scales:{x:{grid:{display:false},ticks:{maxRotation:40,font:{size:10}}},y:{ticks:{callback:v=>'₹'+v/1000+'k'}}}}});
 const n=['in','low','out'].map(k=>S.products.filter(p=>st(p)===k).length);
 c('#c2',{type:'doughnut',data:{labels:['In stock','Low','Out'],datasets:[{data:n,backgroundColor:['#16A34A','#F59E0B','#DC2626'],borderWidth:0}]},options:{...o,cutout:'68%',plugins:{legend:{display:true,position:'bottom'}}}})};
function list(){const q=ui.q.toLowerCase();let a=S.products.filter(p=>(!q||[p.name,p.sku,p.barcode,p.cat,p.supplier].some(x=>String(x).toLowerCase().includes(q)))&&(!ui.cat||p.cat===ui.cat)&&(!ui.stat||st(p)===ui.stat));
 const s={name:(x,y)=>x.name.localeCompare(y.name),qty:(x,y)=>x.qty-y.qty,price:(x,y)=>y.price-x.price,cat:(x,y)=>x.cat.localeCompare(y.cat)||x.name.localeCompare(y.name)};return a.sort(s[ui.sort])}
const opts=(a,v,all)=>`<option value="">${all}</option>`+a.map(o=>`<option ${o===v?'selected':''}>${o}</option>`).join('');
P.inventory=()=>{const a=list();return`<div class="head"><div><h1>Inventory</h1><small>${a.length} of ${S.products.length} products</small></div><button class="btn primary" onclick="prodModal()"><i data-lucide="plus"></i>Add product</button></div>
 <div class="tools"><select onchange="ui.cat=this.value;render()">${opts(CATS,ui.cat,'All categories')}</select><select onchange="ui.stat=this.value;render()"><option value="">All statuses</option>${[['in','In stock'],['low','Low stock'],['out','Out of stock']].map(([k,l])=>`<option value="${k}" ${ui.stat===k?'selected':''}>${l}</option>`).join('')}</select><select onchange="ui.sort=this.value;render()">${[['name','Sort: A–Z'],['qty','Sort: Quantity'],['price','Sort: Price'],['cat','Sort: Category']].map(([k,l])=>`<option value="${k}" ${ui.sort===k?'selected':''}>${l}</option>`).join('')}</select></div>
 ${a.length?`<div class="card tw dt"><table><tr><th>Product<th>SKU<th>Category<th>Stock<th>Status<th>Cost<th>Price<th>Supplier<th></tr>${a.map(p=>`<tr><td><b>${esc(p.name)}</b><td class="mut">${p.sku}<td>${p.cat}<td>${stepper(p)}<td>${badge(p)}<td>${inr(p.cost)}<td>${inr(p.price)}<td>${esc(p.supplier)}<td><button class="btn sm" onclick="prodModal('${p.id}')">Edit</button></tr>`).join('')}</table></div>
 <div class="cards">${a.map(p=>`<div class="card pc"><div class="row" style="border:0;padding:0"><b>${esc(p.name)}</b>${badge(p)}</div><small>${p.cat} · ${p.sku} · Cost ${inr(p.cost)} · Sells ${inr(p.price)}</small><div class="row" style="border:0;padding:0">${stepper(p)}<button class="btn sm" onclick="prodModal('${p.id}')">Edit</button></div></div>`).join('')}</div>`:'<div class="card empty">No products match. Clear the search or filters, or add a product.</div>'}`};
P.alerts=()=>{const a=alerts().sort((x,y)=>x.qty-y.qty);return`<div class="head"><div><h1>Stock alerts</h1><small>Adjust minimum stock right here</small></div><button class="btn primary" onclick="go('reorder')">Open reorder assistant</button></div>
 <div class="card tw">${a.length?`<table><tr><th>Product<th>Status<th>Stock<th>Minimum<th>Supplier</tr>${a.map(p=>`<tr><td><b>${esc(p.name)}</b><td>${badge(p)}<td>${stepper(p)}<td><input class="in" style="width:80px" type="number" min="0" value="${p.min}" onchange="setMin('${p.id}',this.value)"><td>${esc(p.supplier)}</tr>`).join('')}</table>`:'<p class="empty">No alerts. Every product is above its minimum.</p>'}</div>`};
function setMin(id,v){const p=S.products.find(x=>x.id===id);v=parseFloat(v);if(isNaN(v)||v<0)return toast('Enter a valid minimum','error');p.min=v;save();render();toast('Minimum stock updated.')}
function order(){const g={};need().filter(p=>ui.sel[p.id]!==false).forEach(p=>{const q=ui.qty[p.id]??(p.target-p.qty);if(q>0)(g[p.supplier||'Unassigned']=g[p.supplier||'Unassigned']||[]).push({p,q})});return g}
const tot=a=>a.reduce((s,x)=>s+x.q*x.p.cost,0);
function msg(sup,a){return`Hello ${sup},\n\nWe would like to place a stock replenishment order.\n\nOrder items:\n\n${a.map(x=>`${x.p.name} — ${x.q} ${x.p.unit}`).join('\n\n')}\n\nEstimated total: ${inr(tot(a))}\n\nPlease confirm availability and delivery schedule.\n\nThank you,\n${S.store}`}
P.reorder=()=>{const n=need(),g=order(),all=Object.values(g).flat();
 return`<div class="head"><div><h1>Reorder assistant</h1><small>Suggested quantity = target − current stock</small></div><div class="tools" style="margin:0"><button class="btn" onclick="selAll(true)">Select all</button><button class="btn" onclick="selAll(false)">Clear</button><button class="btn" ${all.length?'':'disabled'} onclick="csvOrder()">Export CSV</button></div></div>
 <div class="card" style="margin-bottom:14px"><b>${all.length}</b> items selected · estimated cost <b>${inr(tot(all))}</b><br><small>Messages open in WhatsApp for you to review and send. Nothing is sent automatically.</small></div>
 ${n.length?[...new Set(n.map(p=>p.supplier||'Unassigned'))].map(s=>{const it=n.filter(p=>(p.supplier||'Unassigned')===s),sel=g[s]||[];return`<div class="card sup"><h2><span>${esc(s)}</span><span>${inr(tot(sel))}</span></h2>${it.map(p=>`<div class="row"><label style="display:flex;gap:10px;align-items:center;flex:1;min-height:44px"><input type="checkbox" ${ui.sel[p.id]!==false?'checked':''} onchange="ui.sel['${p.id}']=this.checked;render()"><span>${esc(p.name)}<br><small>${p.sku} · ${p.cat} · stock ${p.qty}/min ${p.min}/target ${p.target} · ${inr(p.cost)}/${p.unit}</small></span></label><input class="in" style="width:80px" type="number" min="0" value="${ui.qty[p.id]??(p.target-p.qty)}" onchange="ui.qty['${p.id}']=Math.max(0,parseFloat(this.value)||0);render()"></div>`).join('')}
 <div class="tools" style="margin:12px 0 0"><button class="btn sm" ${sel.length?'':'disabled'} onclick="copyPO('${esc(s)}')"><i data-lucide="copy"></i>Copy</button><button class="btn sm" ${sel.length?'':'disabled'} onclick="dlPO('${esc(s)}')"><i data-lucide="download"></i>Download</button><button class="btn sm primary" ${sel.length?'':'disabled'} onclick="wa('${esc(s)}')"><i data-lucide="message-circle"></i>WhatsApp</button></div></div>`}).join(''):'<div class="card empty">Nothing to reorder right now.</div>'}`};
const selAll=v=>{need().forEach(p=>ui.sel[p.id]=v);render()};
const poText=s=>msg(s,order()[s]||[]);
function copyPO(s){navigator.clipboard.writeText(poText(s)).then(()=>toast('Copied to clipboard.'),()=>toast('Copy failed. Use Download instead.','error'));toast('Purchase order generated.')}
function dl(name,text,type='text/plain'){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function dlPO(s){dl('purchase-order-'+s.replace(/\W+/g,'-')+'.txt',poText(s));toast('Purchase order generated.')}
function wa(s){const ph=(S.products.find(p=>p.supplier===s&&p.phone)||{}).phone,n=ph?ph.replace(/\D/g,'').replace(/^(\d{10})$/,'91$1'):'';window.open(`https://wa.me/${n}?text=${encodeURIComponent(poText(s))}`,'_blank','noopener');toast('WhatsApp opened. Review the message and press send.')}
const csvc=r=>r.map(c=>`"${String(c).replace(/"/g,'""')}"`).join(',');
function csvOrder(){const rows=[['Supplier','Product','SKU','Qty','Unit','Cost','Total']];Object.entries(order()).forEach(([s,a])=>a.forEach(x=>rows.push([s,x.p.name,x.p.sku,x.q,x.p.unit,x.p.cost,x.q*x.p.cost])));dl('reorder.csv',rows.map(csvc).join('\n'),'text/csv');toast('Purchase order generated.')}
P.ledger=()=>{const q=ui.lf.toLowerCase(),a=S.ledger.filter(t=>(!q||(t.name+t.sku).toLowerCase().includes(q))&&(!ui.lt||t.type===ui.lt));
 return`<div class="head"><div><h1>Stock ledger</h1><small>Every stock change, newest first</small></div></div><div class="tools"><input class="in" style="max-width:260px" placeholder="Filter by product or SKU" value="${esc(ui.lf)}" oninput="ui.lf=this.value;render(true)"><select onchange="ui.lt=this.value;render()">${opts(['Stock In','Stock Out','Sale','Return','Correction'],ui.lt,'All types')}</select></div>
 <div class="card tw">${a.length?`<table><tr><th>ID<th>Date<th>Time<th>Product<th>Type<th>Change<th>Before → After<th>Reason</tr>${a.slice(0,300).map(t=>{const d=new Date(t.ts);return`<tr><td class="mut">${t.id}<td>${d.toLocaleDateString('en-IN')}<td>${d.toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'})}<td>${esc(t.name)}<br><small>${t.sku}</small><td><span class="badge ${t.change>0?'b-in':'b-out'}">${t.type}</span><td><b>${t.change>0?'+':''}${t.change}</b><td>${t.prev} → ${t.now}<td>${t.reason}</tr>`}).join('')}</table>`:'<p class="empty">No transactions yet. Change any product\'s stock and it will appear here.</p>'}</div>`};
const expBadge=p=>{const d=dleft(p);return d<0?'<span class="badge b-out">Expired</span>':d<=7?`<span class="badge b-out">${d}d left</span>`:d<=15?`<span class="badge b-low">${d}d left</span>`:d<=30?`<span class="badge b-low">${d}d left</span>`:`<span class="badge b-in">${d}d left</span>`};
P.expiry=()=>{const a=S.products.filter(p=>p.expiry&&dleft(p)<=30).sort((x,y)=>dleft(x)-dleft(y)),grp=[['Expired',p=>dleft(p)<0],['Within 7 days',p=>dleft(p)>=0&&dleft(p)<=7],['Within 15 days',p=>dleft(p)>7&&dleft(p)<=15],['Within 30 days',p=>dleft(p)>15]];
 return`<div class="head"><div><h1>Expiry tracker</h1><small>Products expiring in the next 30 days</small></div></div>${grp.map(([l,f])=>{const it=a.filter(f);return`<div class="card sup tw"><h2 style="padding:14px 16px 0">${l} (${it.length})</h2>${it.length?`<table><tr><th>Product<th>Category<th>Qty<th>Expiry date<th>Days<th>Stock value<th></tr>${it.map(p=>`<tr><td><b>${esc(p.name)}</b><td>${p.cat}<td>${p.qty} ${p.unit}<td><input class="in" style="width:150px" type="date" value="${p.expiry}" onchange="setExp('${p.id}',this.value)"><td>${expBadge(p)}<td>${inr(p.qty*p.cost)}<td></tr>`).join('')}</table>`:'<p class="empty" style="padding:14px">None.</p>'}</div>`}).join('')}`};
function setExp(id,v){S.products.find(p=>p.id===id).expiry=v;save();render();toast('Expiry date updated.')}
P.settings=()=>`<div class="head"><h1>Settings</h1></div><div class="grid two" style="grid-template-columns:1fr 1fr"><div class="card"><h2>Store profile</h2><div class="form" style="grid-template-columns:1fr"><label>Store name<input class="in" id="s_name" value="${esc(S.store)}"></label><label>Currency<select disabled><option>Indian Rupee (₹)</option></select></label></div><button class="btn primary" onclick="S.store=$('#s_name').value.trim()||S.store;save();render();toast('Store profile saved.')">Save</button></div>
 <div class="card"><h2>Data</h2><div class="grid" style="margin-top:12px"><button class="btn" onclick="expCSV()"><i data-lucide="file-spreadsheet"></i>Export inventory CSV</button><button class="btn" onclick="expJSON()"><i data-lucide="download"></i>Download JSON backup</button><label class="btn"><i data-lucide="upload"></i>Restore backup<input type="file" accept=".json" hidden onchange="impJSON(this.files[0])"></label><button class="btn danger" onclick="confirmM('This replaces all data with the sample inventory and clears the ledger.',()=>{seed();render();toast('Sample inventory restored.')})"><i data-lucide="rotate-ccw"></i>Reset sample inventory</button></div></div></div>
 <p class="mut" style="margin-top:14px">Low-stock rule: a product is low when quantity is at or below its minimum. Edit minimums in Inventory or Stock Alerts.</p>`;
function expCSV(){const h=['ID','Name','SKU','Barcode','Category','Unit','Cost','Price','Qty','Min','Target','Supplier','Phone','Expiry'];dl('inventory.csv',[h,...S.products.map(p=>[p.id,p.name,p.sku,p.barcode,p.cat,p.unit,p.cost,p.price,p.qty,p.min,p.target,p.supplier,p.phone,p.expiry])].map(csvc).join('\n'),'text/csv');toast('Inventory CSV downloaded.')}
function expJSON(){dl('stocksherpa-backup.json',JSON.stringify(S,null,1),'application/json');toast('Inventory backup downloaded.')}
function impJSON(f){if(!f)return;const r=new FileReader();r.onload=()=>{try{const d=JSON.parse(r.result);if(!Array.isArray(d.products)||!Array.isArray(d.ledger)||!d.products.every(p=>p.id&&p.name&&typeof p.qty==='number'&&p.qty>=0&&typeof p.cost==='number'&&typeof p.price==='number'))throw 0;
 confirmM(`Replace current data with this backup (${d.products.length} products)?`,()=>{S=d;S.store=S.store||'My Store';save();render();toast('Backup restored.')})}catch(e){toast('Invalid backup file.','error')}};r.readAsText(f)}
// ---------- shell ----------
function go(p){ui.page=p;$('#side').classList.remove('open');$('#scrim').classList.remove('open');render();scrollTo(0,0)}
function render(keepFocus){charts.forEach(c=>c.destroy());charts=[];
 const n=alerts().length;$('#nav').innerHTML=PAGES.map(([k,l,i])=>`<a class="${ui.page===k?'on':''}" onclick="go('${k}')"><i data-lucide="${i}"></i>${l}${k==='alerts'&&n?`<span class="n">${n}</span>`:''}</a>`).join('');
 $('#storeName').textContent=S.store;$('#bellN').textContent=n||'';
 const ae=document.activeElement,id=ae&&ae.id,pos=ae&&ae.selectionStart;
 $('#view').innerHTML=P[ui.page]();P[ui.page].after&&P[ui.page].after();icons();
 if(keepFocus&&ae&&ae.placeholder){const x=document.querySelector('#view input.in');x&&(x.focus(),x.setSelectionRange(pos,pos))}}
$('#q').oninput=e=>{ui.q=e.target.value;$('#qc').hidden=!ui.q;if(ui.page!=='inventory')ui.page='inventory';render();const m=S.products.filter(p=>p.barcode===ui.q.trim());if(m.length===1)adjModal(m[0].id)};
$('#qc').onclick=()=>{$('#q').value='';ui.q='';$('#qc').hidden=true;render()};
$('#addTop').onclick=()=>prodModal();$('#bell').onclick=()=>go('alerts');
$('#burger').onclick=()=>{$('#side').classList.add('open');$('#scrim').classList.add('open')};$('#scrim').onclick=()=>{$('#side').classList.remove('open');$('#scrim').classList.remove('open')};
S=load();if(!S)seed();render();
